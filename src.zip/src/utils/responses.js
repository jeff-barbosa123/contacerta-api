export function successResponse(data, mensagem='OK') {
  return { status: 200, mensagem, data };
}

export function errorResponse(status = 500, mensagem='Erro interno do servidor') {
  return { status, mensagem };
}
