import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import { fileURLToPath } from 'url';
import { produtos } from '../models/produtosModel.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const configPath = path.join(__dirname, '../config/cmv.json');
const historyPath = path.join(__dirname, '../logs/cmv_history.json');

let cache = { valor: null, atualizadoEm: null, origem: 'desconhecida' };

function readJSON(file) { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
function writeJSON(file, obj) { fs.writeFileSync(file, JSON.stringify(obj, null, 2)); }

function logHistory(entry) {
  const list = fs.existsSync(historyPath) ? JSON.parse(fs.readFileSync(historyPath, 'utf-8')) : [];
  list.push(entry);
  fs.writeFileSync(historyPath, JSON.stringify(list, null, 2));
}

async function byAPI(cfg) {
  const url = process.env.API_URL || cfg.api?.url;
  const token = process.env.API_TOKEN || cfg.api?.token;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (typeof data.cmv === 'undefined') throw new Error('Campo cmv ausente');
  return { valor: Number(data.cmv), origem: 'api' };
}
function byCSV(cfg) {
  const csv = path.resolve(cfg.arquivo?.path || '');
  if (!fs.existsSync(csv)) throw new Error('CSV não encontrado');
  const [header, first] = fs.readFileSync(csv, 'utf-8').trim().split(/\r?\n/);
  const idx = header.split(',').indexOf(cfg.arquivo?.coluna_cmv || 'cmv');
  if (idx < 0 || !first) throw new Error('CSV inválido');
  const val = Number(first.split(',')[idx]);
  return { valor: val, origem: 'csv' };
}
function byInternal() {
  if (!produtos?.length) throw new Error('Sem produtos');
  const media = produtos.reduce((a,p)=>a+Number(p.custo||0),0)/produtos.length;
  return { valor: Number(media.toFixed(4)), origem: 'interno' };
}

export async function atualizarCMV() {
  const cfg = readJSON(configPath);
  const modo = (cfg.metodo || 'auto').toLowerCase();
  const ordem = modo==='auto' ? ['api','arquivo','interno','fixo'] : [modo];
  let valor = null, origem='fixo';

  for (const fonte of ordem) {
    try {
      if (fonte==='api') ({valor, origem}=await byAPI(cfg));
      else if (fonte==='arquivo') ({valor, origem}=byCSV(cfg));
      else if (fonte==='interno' && cfg.calculo_interno?.ativo) ({valor, origem}=byInternal());
      else if (fonte==='fixo') { valor=Number(cfg.fixo); origem='fixo'; }
      if (valor!=null && !Number.isNaN(valor)) break;
    } catch (e) {
      console.log(`⚠️ Falha na fonte ${fonte}: ${e.message}`);
    }
  }

  if (valor==null || Number.isNaN(valor)) {
    valor = cache.valor ?? Number(cfg.fixo ?? 0.3);
    origem = cache.valor ? 'cache' : 'fixo';
  }

  cache = { valor, atualizadoEm: new Date().toISOString(), origem };
  cfg.fixo = valor;
  cfg.ultima_atualizacao = cache.atualizadoEm;
  writeJSON(configPath, cfg);
  logHistory({ data: cache.atualizadoEm, origem, valor });
  console.log(`✅ CMV atualizado (${origem}): ${valor}`);
  return cache;
}

export function obterCMVAtual() {
  if (cache.valor!=null) return cache;
  const cfg = readJSON(configPath);
  return { valor: Number(cfg.fixo), atualizadoEm: cfg.ultima_atualizacao, origem: cfg.metodo || 'fixo' };
}