export const produtos = [
  { id: 1, nome: 'Bolo de Rolo', custo: 12.5, preco: 25.0, estoque: 30 },
  { id: 2, nome: 'Coxinha de Frango', custo: 3.0, preco: 6.0, estoque: 100 },
];