export const pedidos = [
  { id: 1, clienteId: 1, itens: [{ produtoId: 1, quantidade: 2}, { produtoId: 2, quantidade: 5 }], data: '2025-10-01' }
];
