export const clientes = [
  { id: 1, nome: 'Maria Souza', telefone: '(81) 98888-7777', aniversario: '1990-03-25' },
  { id: 2, nome: 'João Silva', telefone: '(81) 97777-6666', aniversario: '1985-11-12' },
];