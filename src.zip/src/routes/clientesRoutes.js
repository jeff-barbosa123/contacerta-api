import { Router } from 'express';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { listClientes, createCliente, updateCliente, deleteCliente } from '../controllers/clientesController.js';

const r = Router();
r.use(authMiddleware);
r.get('/', listClientes);
r.post('/', createCliente);
r.put('/:id', updateCliente);
r.delete('/:id', deleteCliente);
export default r;
