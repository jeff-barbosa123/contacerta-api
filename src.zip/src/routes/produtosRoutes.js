import { Router } from 'express';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { listProdutos, createProduto, updateProduto, deleteProduto } from '../controllers/produtosController.js';

const r = Router();
r.use(authMiddleware);
r.get('/', listProdutos);
r.post('/', createProduto);
r.put('/:id', updateProduto);
r.delete('/:id', deleteProduto);
export default r;
