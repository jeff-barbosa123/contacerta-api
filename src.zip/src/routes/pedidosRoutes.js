import { Router } from 'express';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { listPedidos, createPedido } from '../controllers/pedidosController.js';

const r = Router();
r.use(authMiddleware);
r.get('/', listPedidos);
r.post('/', createPedido);
export default r;
