import { Router } from 'express';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { cmvController, rendimentoController } from '../controllers/relatoriosController.js';

const r = Router();
r.use(authMiddleware);
r.get('/cmv', cmvController);
r.get('/rendimento', rendimentoController);
export default r;
