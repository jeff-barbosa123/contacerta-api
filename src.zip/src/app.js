import express from 'express';
import cors from 'cors';
import swaggerUi from 'swagger-ui-express';
import YAML from 'yamljs';

import authRoutes from './routes/authRoutes.js';
import clientesRoutes from './routes/clientesRoutes.js';
import produtosRoutes from './routes/produtosRoutes.js';
import pedidosRoutes from './routes/pedidosRoutes.js';
import relatoriosRoutes from './routes/relatoriosRoutes.js';

import { errorHandler } from './middlewares/errorHandler.js';
import { scheduleCmvUpdater } from './services/cmvService.js';

const app = express();
app.use(express.json());

// ✅ Configuração do CORS
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ✅ Swagger
const swaggerDocument = YAML.load('./src/recursos/swagger.yaml');
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// ✅ Prefixo padronizado para todas as rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/clientes', clientesRoutes);
app.use('/api/produtos', produtosRoutes);
app.use('/api/pedidos', pedidosRoutes);
app.use('/api/relatorios', relatoriosRoutes);

// ✅ Status simples
app.get('/', (req, res) => res.json({ status: 'API ContaCerta em execução' }));

// ✅ Erros globais
app.use(errorHandler);

// ✅ Agenda de atualização do CMV (cron)
scheduleCmvUpdater();

export default app;
