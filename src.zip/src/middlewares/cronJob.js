import cron from 'node-cron';
import { atualizarCMV } from '../utils/cmvCalculator.js';

export function iniciarJobCMV() {
  console.log('🔁 Iniciando job automático do CMV...');
  atualizarCMV();
  const horas = Number(process.env.UPDATE_INTERVAL_HOURS || 6);
  const expr = `0 */${horas} * * *`;
  cron.schedule(expr, async () => {
    console.log('⏱️ Executando atualização automática do CMV...');
    await atualizarCMV();
  });
  console.log(`✅ Job configurado: a cada ${horas} hora(s).`);
}