import { errorResponse } from '../utils/responses.js';

export default function errorHandler(err, req, res, next) { // eslint-disable-line
  console.error('[ERRO]', err?.status || 500, err?.message || err);
  const status = Number.isInteger(err?.status) ? err.status : 500;
  const mensagem = err?.message || 'Erro interno do servidor';
  return res.status(status).json(errorResponse(status, mensagem));
}

export { errorHandler };
