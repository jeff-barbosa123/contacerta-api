import { ClienteService } from '../services/clienteService.js';
import { successResponse } from '../utils/responses.js';

export function listClientes(req, res, next) {
  try {
    res.json(successResponse(ClienteService.list()));
  } catch (e) { next(e); }
}

export function createCliente(req, res, next) {
  try {
    const novo = ClienteService.create(req.body);
    res.status(201).json(successResponse(novo, 'Cliente cadastrado com sucesso'));
  } catch (e) { next(e); }
}

export function updateCliente(req, res, next) {
  try {
    const upd = ClienteService.update(Number(req.params.id), req.body);
    res.json(successResponse(upd, 'Cliente atualizado'));
  } catch (e) { next(e); }
}

export function deleteCliente(req, res, next) {
  try {
    ClienteService.remove(Number(req.params.id));
    res.json(successResponse(true, 'Cliente removido'));
  } catch (e) { next(e); }
}
