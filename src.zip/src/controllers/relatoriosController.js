import { RelatorioService } from '../services/relatorioService.js';
import { successResponse } from '../utils/responses.js';

export function cmvController(req, res, next) {
  try {
    res.json(successResponse(RelatorioService.cmv()));
  } catch (e) { next(e); }
}

export function rendimentoController(req, res, next) {
  try {
    res.json(successResponse(RelatorioService.rendimento()));
  } catch (e) { next(e); }
}
