import { PedidoService } from '../services/pedidoService.js';
import { successResponse } from '../utils/responses.js';

export function listPedidos(req, res, next) {
  try {
    res.json(successResponse(PedidoService.list()));
  } catch (e) { next(e); }
}

export function createPedido(req, res, next) {
  try {
    const novo = PedidoService.create(req.body);
    res.status(201).json(successResponse(novo, 'Pedido registrado'));
  } catch (e) { next(e); }
}
