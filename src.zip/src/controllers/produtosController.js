import { ProdutoService } from '../services/produtoService.js';
import { successResponse } from '../utils/responses.js';

export function listProdutos(req, res, next) {
  try {
    res.json(successResponse(ProdutoService.list()));
  } catch (e) { next(e); }
}

export function createProduto(req, res, next) {
  try {
    const novo = ProdutoService.create(req.body);
    res.status(201).json(successResponse(novo, 'Produto cadastrado com sucesso'));
  } catch (e) { next(e); }
}

export function updateProduto(req, res, next) {
  try {
    const upd = ProdutoService.update(Number(req.params.id), req.body);
    res.json(successResponse(upd, 'Produto atualizado'));
  } catch (e) { next(e); }
}

export function deleteProduto(req, res, next) {
  try {
    ProdutoService.remove(Number(req.params.id));
    res.json(successResponse(true, 'Produto removido'));
  } catch (e) { next(e); }
}
