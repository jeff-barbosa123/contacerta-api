import { produtos } from '../models/produtosModel.js';
import { pedidos } from '../models/pedidosModel.js';
import { obterCMVAtual } from '../utils/cmvCalculator.js';

export function calcularCMV() {
  let total = 0;
  pedidos.forEach(p => {
    p.itens.forEach(item => {
      const prod = produtos.find(pr => pr.id === item.produtoId);
      if (prod) total += Number(prod.custo) * Number(item.quantidade);
    });
  });
  const vigente = obterCMVAtual();
  return { cmv_total: Number(total.toFixed(2)), cmv_vigente: vigente };
}

export function calcularRendimento() {
  const rel = [];
  pedidos.forEach(p => {
    p.itens.forEach(item => {
      const prod = produtos.find(pr => pr.id === item.produtoId);
      if (prod) {
        const lucroU = Number(prod.preco) - Number(prod.custo);
        const margem = (lucroU / Number(prod.custo)) * 100;
        const rend = lucroU * Number(item.quantidade);
        rel.push({
          produto: prod.nome,
          custo_unitario: prod.custo,
          preco_venda: prod.preco,
          quantidade: item.quantidade,
          lucro_unitario: Number(lucroU.toFixed(2)),
          margem_percentual: `${margem.toFixed(2)}%`,
          rendimento_total: Number(rend.toFixed(2))
        });
      }
    });
  });
  const vigente = obterCMVAtual();
  return { cmv_vigente: vigente, itens: rel };
}