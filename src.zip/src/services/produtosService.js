import { produtos } from '../models/produtos.js';

export function listarProdutos() {
  return produtos;
}

export function criarProduto({ nome, custo, preco, estoque }) {
  const id = produtos.length ? Math.max(...produtos.map(p => p.id)) + 1 : 1;
  const novo = { id, nome, custo: Number(custo), preco: Number(preco), estoque: Number(estoque || 0) };
  produtos.push(novo);
  return novo;
}
