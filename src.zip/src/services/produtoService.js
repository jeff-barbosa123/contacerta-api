import { Produtos } from '../models/produtosModel.js';
import { requireFields } from '../utils/validation.js';

export const ProdutoService = {
  list() { return Produtos.list(); },
  create(data) {
    requireFields(data, ['nome', 'custo', 'preco', 'estoque']);
    data.custo = Number(data.custo); data.preco = Number(data.preco); data.estoque = Number(data.estoque);
    return Produtos.create(data);
  },
  update(id, data) {
    const upd = Produtos.update(id, data);
    if (!upd) { const e = new Error('Produto não encontrado'); e.status = 404; throw e; }
    return upd;
  },
  remove(id) {
    const ok = Produtos.remove(id);
    if (!ok) { const e = new Error('Produto não encontrado'); e.status = 404; throw e; }
    return true;
  }
};
