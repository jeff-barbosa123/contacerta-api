import { pedidos } from '../models/pedidos.js';
import { produtos } from '../models/produtos.js';
import { clientes } from '../models/clientes.js';

export function listarPedidos() {
  return pedidos;
}

export function criarPedido({ clienteId, itens }) {
  const id = pedidos.length ? Math.max(...pedidos.map(p => p.id)) + 1 : 1;
  // validação simples
  const cliente = clientes.find(c => c.id === Number(clienteId));
  if (!cliente) throw { status: 400, message: 'Cliente inválido' };

  itens.forEach(i => {
    const prod = produtos.find(p => p.id === Number(i.produtoId));
    if (!prod) throw { status: 400, message: `Produto inválido: ${i.produtoId}` };
    if (prod.estoque < i.quantidade) throw { status: 400, message: `Estoque insuficiente para produto ${prod.nome}` };
    prod.estoque -= i.quantidade;
  });

  const novo = { id, clienteId: Number(clienteId), itens, data: new Date().toISOString().slice(0,10) };
  pedidos.push(novo);
  return novo;
}
