import { clientes } from '../models/clientes.js';

export function listarClientes() {
  return clientes;
}

export function criarCliente({ nome, telefone, aniversario }) {
  const id = clientes.length ? Math.max(...clientes.map(c => c.id)) + 1 : 1;
  const novo = { id, nome, telefone, aniversario, totalConsumido: 0 };
  clientes.push(novo);
  return novo;
}
