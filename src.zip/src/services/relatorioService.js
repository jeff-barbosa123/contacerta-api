import { Pedidos } from '../models/pedidosModel.js';
import { Produtos } from '../models/produtosModel.js';
import { lucroUnitario, margemPercentual } from '../utils/calculations.js';
import { getCmvBase } from './cmvService.js';

export const RelatorioService = {
  cmv() {
    const cmvBase = getCmvBase(); // custo base atual
    // Soma CMV dos itens vendidos com base no custo do produto (ou cmvBase se quiser)
    let cmvTotal = 0;
    for (const ped of Pedidos.list()) {
      for (const item of ped.itens) {
        const prod = Produtos.list().find(p => p.id === item.produto_id);
        if (prod) {
          cmvTotal += (prod.custo ?? cmvBase) * item.quantidade;
        }
      }
    }
    return { cmv_total: Number(cmvTotal.toFixed(2)), cmv_base: cmvBase };
  },

  rendimento() {
    // Lucro e margem por produto baseado em vendas
    const mapa = new Map();
    for (const ped of Pedidos.list()) {
      for (const item of ped.itens) {
        const prod = Produtos.list().find(p => p.id === item.produto_id);
        if (!prod) continue;
        const key = prod.id;
        const atual = mapa.get(key) || { produto: prod.nome, custo_unitario: prod.custo, preco_venda: prod.preco, quantidade: 0 };
        atual.quantidade += Number(item.quantidade || 0);
        mapa.set(key, atual);
      }
    }
    const saida = [];
    for (const v of mapa.values()) {
      const lucro_unit = lucroUnitario(v.preco_venda, v.custo_unitario);
      const margem = margemPercentual(v.preco_venda, v.custo_unitario);
      const rendimento_total = Number((lucro_unit * v.quantidade).toFixed(2));
      saida.push({
        produto: v.produto,
        custo_unitario: v.custo_unitario,
        preco_venda: v.preco_venda,
        quantidade: v.quantidade,
        lucro_unitario: lucro_unit,
        margem_percentual: margem,
        rendimento_total
      });
    }
    return saida;
  }
};
