import { Pedidos } from '../models/pedidosModel.js';
import { Produtos } from '../models/produtosModel.js';
import { requireFields } from '../utils/validation.js';

export const PedidoService = {
  list() { return Pedidos.list(); },
  create(data) {
    requireFields(data, ['cliente_id', 'itens']);
    // Calcula total
    let total = 0;
    for (const item of data.itens) {
      const prod = Produtos.list().find(p => p.id === item.produto_id);
      if (!prod) { const e = new Error(`Produto ${item.produto_id} não encontrado`); e.status = 400; throw e; }
      total += prod.preco * Number(item.quantidade || 0);
    }
    const novo = Pedidos.create({ ...data, total });
    return novo;
  }
};
