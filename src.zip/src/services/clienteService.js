import { Clientes } from '../models/clientesModel.js';
import { requireFields } from '../utils/validation.js';

export const ClienteService = {
  list() { return Clientes.list(); },
  create(data) {
    requireFields(data, ['nome', 'telefone', 'aniversario']);
    return Clientes.create(data);
  },
  update(id, data) {
    const upd = Clientes.update(id, data);
    if (!upd) { const e = new Error('Cliente não encontrado'); e.status = 404; throw e; }
    return upd;
  },
  remove(id) {
    const ok = Clientes.remove(id);
    if (!ok) { const e = new Error('Cliente não encontrado'); e.status = 404; throw e; }
    return true;
  }
};
